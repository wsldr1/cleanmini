=== Theme Name ===
Contributors: wsldr
Requires at least: 5.0
Tested up to: 5.2
Requires PHP: 5.6
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html


== Description ==
Clean, simple and practical. If this is all you need, then this theme is for you.


== Changelog ==

= 1.0 = Release version

== Resources ==

* Alpha Color Picker](https://github.com/BraadMartin/components/blob/master/demos/alpha-color-picker.gif) gpl license

 